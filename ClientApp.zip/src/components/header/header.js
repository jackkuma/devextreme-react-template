import React from 'react';
import Toolbar, { Item } from 'devextreme-react/toolbar';
import Button from 'devextreme-react/button';
import UserPanel from '../user-panel/user-panel';
import './header.scss';
import { Template } from 'devextreme-react/core/template';

export default ({ menuToggleEnabled, title, toggleMenu }) => (
  <header className={'header-component'}>
    <Toolbar className={'header-toolbar'}>
      <Item
        location={'before'}
        cssClass={'header-title'}
        text={title}
        visible={!!title}
      />
      <Item
        location={'after'}
        locateInMenu={'auto'}
        menuItemTemplate={'userPanelTemplate'}
      >
        <Button
          className={'user-button authorization'}
          width={210}
          height={'100%'}
          stylingMode={'text'}
        >
          <UserPanel menuMode={'context'} />
        </Button>
      </Item>
      <Template name={'userPanelTemplate'}>
        <UserPanel menuMode={'list'} />
      </Template>
      <Item
        visible={menuToggleEnabled}
        location={'after'}
        widget={'dxButton'}
        cssClass={'menu-button'}
       >
         <Button icon="home" stylingMode="text" onClick={toggleMenu} />
      </Item>
    </Toolbar>
  </header>
);

