export default {
  title: 'AppTitle'
};
